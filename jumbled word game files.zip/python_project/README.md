# Quizee

To run the program follow the following steps 
1.Download ZIP file 
2.Extract ZIP file 
3.Click on QUIZEE-master
4.Click on main_start
